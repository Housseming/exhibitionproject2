import { Component } from '@angular/core';
import { PdfService } from '../pdf.service';
import { Router } from '@angular/router';

@Component({
selector: 'app-upload-page',
template: `
<input type="file" (change)="onFileSelected($event)" accept=".pdf">
`
})
export class UploadPageComponent {
constructor(private pdfService: PdfService, private router: Router) {}

  onFileSelected(event: any): void {
    const file = event.target.files[0];
    if (file) {
      console.log('Fichier sélectionné :', file.name);
      this.pdfService.setFile(file); // Stocker le fichier dans le service
      this.router.navigate(['/select']); // Rediriger vers la page suivante
    } else {
      console.error("Aucun fichier sélectionné.");
    }
  }
}
