import { Component, ViewChild, ElementRef, OnInit } from '@angular/core';
import * as pdfjsLib from 'pdfjs-dist';
import { PdfService } from '../pdf.service';

// Configuration unique du workerSrc pour la version 3.11.174
(pdfjsLib as any).GlobalWorkerOptions.workerSrc =
  `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js`;

@Component({
  selector: 'app-selection-page',
  template: `<canvas #pdfCanvas (click)="onCanvasClick($event)" style="border: 1px solid black;"></canvas>`
})
export class SelectionPageComponent implements OnInit {
  @ViewChild('pdfCanvas') pdfCanvas!: ElementRef<HTMLCanvasElement>;
  private zones: any[] = []; // Stocke les zones détectées

  constructor(private pdfService: PdfService) {}

  ngOnInit() {
    const file = this.pdfService.getFile();
    if (file) {
      const fileReader = new FileReader();
      fileReader.onload = () => {
        const typedArray = new Uint8Array(fileReader.result as ArrayBuffer);
        const loadingTask = pdfjsLib.getDocument({ data: typedArray } as any);
        loadingTask.promise.then((pdf: any) => {
          pdf.getPage(1).then((page: any) => {
            const viewport = page.getViewport({ scale: 1.5 });
            const canvas = this.pdfCanvas.nativeElement;
            const context = canvas.getContext('2d');
            if (context) {
              canvas.height = viewport.height;
              canvas.width = viewport.width;
              const renderContext = {
                canvasContext: context,
                viewport: viewport
              };
              page.render(renderContext).promise.then(() => {
                this.analyzeCanvas(context, canvas.width, canvas.height);
              });
            } else {
              console.error("Impossible d'obtenir le contexte du canvas.");
            }
          });
        }).catch((error: any) => {
          console.error('Erreur lors du chargement du PDF :', error);
        });
      };
      fileReader.readAsArrayBuffer(file);
    } else {
      console.error('Aucun fichier PDF trouvé.');
    }
  }

  analyzeCanvas(context: CanvasRenderingContext2D, width: number, height: number) {
    const imageData = context.getImageData(0, 0, width, height);
    const data = imageData.data;
    const detectedZones: any[] = [];
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const index = (y * width + x) * 4;
        const [r, g, b] = [data[index], data[index + 1], data[index + 2]];
        if (r < 50 && g < 50 && b < 50) {
          const zone = this.detectSingleOpeningZone(data, width, height, x, y);
          if (zone) detectedZones.push(zone);
        }
      }
    }
    this.zones = this.mergeZones(detectedZones);
    this.processZones(this.zones, context);
  }

  detectSingleOpeningZone(data: Uint8ClampedArray, width: number, height: number, startX: number, startY: number) {
    let endX = startX;
    let endY = startY;

    while (endX < width && data[(startY * width + endX) * 4] < 50) endX++;
    while (endY < height && data[(endY * width + startX) * 4] < 50) endY++;

    let openBorders = 0;
    if (this.isBorderOpen(data, width, startX, startY, endX, startY)) openBorders++;
    if (this.isBorderOpen(data, width, startX, endY, endX, endY)) openBorders++;
    if (this.isBorderOpen(data, width, startX, startY, startX, endY)) openBorders++;
    if (this.isBorderOpen(data, width, endX, startY, endX, endY)) openBorders++;

    if (openBorders === 1) {
        return { x: startX, y: startY, width: endX - startX, height: endY - startY };
    }
    return null;
  }

  isBorderOpen(data: Uint8ClampedArray, width: number, x1: number, y1: number, x2: number, y2: number): boolean {
    for (let x = x1; x <= x2; x++) {
      for (let y = y1; y <= y2; y++) {
        const index = (y * width + x) * 4;
        if (data[index] > 200 && data[index + 1] > 200 && data[index + 2] > 200) {
          return true;
        }
      }
    }
    return false;
  }

  processZones(zones: any[], context: CanvasRenderingContext2D) {
    zones.forEach(zone => {
        let color = 'red';
        this.drawZone(context, zone.x, zone.y, zone.width, zone.height, color);
        this.zones.push({ ...zone, color });
    });
  }

  drawZone(context: CanvasRenderingContext2D, x: number, y: number, width: number, height: number, color: string) {
    context.fillStyle = color;
    context.fillRect(x, y, width, height);
    context.strokeStyle = 'black';
    context.lineWidth = 2;
    context.strokeRect(x, y, width, height);
  }

  onCanvasClick(event: MouseEvent) {
    const rect = this.pdfCanvas.nativeElement.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    this.zones.forEach(zone => {
      if (
        x >= zone.x &&
        x <= zone.x + zone.width &&
        y >= zone.y &&
        y <= zone.y + zone.height
      ) {
        alert(`Vous avez cliqué sur une zone ${zone.color}`);
      }
    });
  }


  mergeZones(zones: any[]): any[] {
    // Stocke les zones fusionnées
    const mergedZones: any[] = [];
  
    zones.forEach(zone => {
      let merged = false;
  
      for (let i = 0; i < mergedZones.length; i++) {
        let existing = mergedZones[i];
  
        // Vérifier si la zone actuelle est proche d'une zone existante
        if (
          Math.abs(existing.x - zone.x) < 20 &&
          Math.abs(existing.y - zone.y) < 20
        ) {
          // Ajuster la largeur et la hauteur pour fusionner les zones proches
          existing.width = Math.max(existing.width, zone.x + zone.width - existing.x);
          existing.height = Math.max(existing.height, zone.y + zone.height - existing.y);
          merged = true;
          break;
        }
      }
  
      // Ajouter la zone si elle n'a pas pu être fusionnée
      if (!merged) {
        mergedZones.push(zone);
      }
    });
  
    return mergedZones;
  }

  detectRectangle(data: Uint8ClampedArray, width: number, height: number, startX: number, startY: number) {
    const maxWidth = 200; // Largeur maximale d'une zone
    const maxHeight = 200; // Hauteur maximale d'une zone
  
    let endX = startX;
    let endY = startY;
  
    // Détection de la bordure droite
    while (endX < width && data[(startY * width + endX) * 4] < 50) endX++;
    // Détection de la bordure basse
    while (endY < height && data[(endY * width + startX) * 4] < 50) endY++;
  
    // Vérification que la zone est un rectangle valide
    if (endX - startX > 10 && endY - startY > 10 && endX - startX < maxWidth && endY - startY < maxHeight) {
      // Marquer la zone comme analysée pour éviter des doublons
      for (let y = startY; y < endY; y++) {
        for (let x = startX; x < endX; x++) {
          const index = (y * width + x) * 4;
          data[index] = 255; // Marquer le pixel comme blanc (analysé)
          data[index + 1] = 255;
          data[index + 2] = 255;
        }
      }
  
      return { x: startX, y: startY, width: endX - startX, height: endY - startY };
    }
  
    return null;
  }
  
  
}
