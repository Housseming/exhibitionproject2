import { Injectable } from '@angular/core';

@Injectable({
providedIn: 'root'
})
export class PdfService {
private uploadedFile: File | null = null;

// Méthode pour définir le fichier
setFile(file: File): void {
    this.uploadedFile = file;
  }

  // Méthode pour récupérer le fichier
  getFile(): File | null {
    return this.uploadedFile;
  }
}
